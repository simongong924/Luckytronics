import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';
import React, { Component } from 'react';
import axios from 'axios';
import UploadScreen from './UploadScreen';
class Login extends Component {
constructor(props){
  super(props);
  this.state={
  "you have logged in"
  }
 }}
